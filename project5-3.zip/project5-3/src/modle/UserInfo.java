package modle;

import java.io.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.*;
public class UserInfo {
   private String username ;
   private String password ;
   public void setUsername (String Username){
       this.username = Username;
    }
    public void setPassword (String Password){
        this.password = Password;
    }

    public String getUsername (){
        return username ;
    }
    public String getPassword (){
        return password;
    }

    public boolean checkUsername(String username)
    {
        File user = new File("User.txt");
        if(user.exists())
        {
            String[] name = user.list();
            for (int i = 0; i < name.length; i++) {
                if(name[i].startsWith(username))
                {
                   return false ;
                }
            }
        }
        return true;
    }
    public static String StrongPassword(String input)
    {
        // Checking lower alphabet in string
        int n = input.length();
        boolean hasLower = false, hasUpper = false,
                hasDigit = false, specialChar = false;
        Set<Character> set = new HashSet<Character>(
                Arrays.asList('!', '@', '#', '$', '%', '^', '&',
                        '*', '(', ')', '-', '+'));
        for (char i : input.toCharArray())
        {
            if (Character.isLowerCase(i))
                hasLower = true;
            if (Character.isUpperCase(i))
                hasUpper = true;
            if (Character.isDigit(i))
                hasDigit = true;
            if (set.contains(i))
                specialChar = true;
        }

        System.out.print("Strength of password:- ");
        if (hasDigit && hasLower && hasUpper && specialChar
                && (n >= 8)) {
            System.out.println(" Strong :)");
            return "strong" ;
        }
        else {
            System.out.println(" Weak please try again :( ");
            return "weak";
        }
    }
    public static String makepassword()
    {
        Scanner input = new Scanner(System.in);
        System.out.println("Please Enter Password Include Number,Character,Lower case" +
                ",Upper Case And At Least 8 Character");
        String password = input.nextLine();
        System.out.println("Please Enter Password again ... ");
        String password2 = input.nextLine();
        while (!password.equals(password2))
        {
            System.out.println("Password does not match try again ... ");
            System.out.println("Please Enter Password ... ");
            password = input.nextLine();
            System.out.println("Please Enter Password again ... ");
            password2 = input.nextLine();
        }
        String power = UserInfo.StrongPassword(password);
        while (power.equals("weak")) {
            System.out.println("Please Enter Password ... ");
            String passwordte = input.nextLine();
            System.out.println("Please Enter Password again ... ");
            String passwordte2 = input.nextLine();
            if (passwordte2.equals(passwordte)) {
                power = UserInfo.StrongPassword(passwordte);
            } else {
                System.out.println("Password does not match try again ... ");
            }
            password = passwordte;
        }
        return password;
    }
    public static void writeToUser(String model) throws IOException {
        File user = new File("User.txt");
        // list that holds strings of a file
        List<String> listOfStrings = new ArrayList<String>();
        // load data from file
        BufferedReader bf = new BufferedReader(new FileReader("User.txt"));
        // read entire line as string
        String line = bf.readLine();
        // checking for end of file
        while (line != null) {
            listOfStrings.add(line);
            line = bf.readLine();
        }
        bf.close();
        String[] data = listOfStrings.toArray(new String[0]);

        FileWriter writer = new FileWriter("User.txt");
        for(int i=0 ; i<data.length ; i++)
            writer.append(data[i]+"\n");
        writer.append(model+"\n");
        writer.close();
        String userfollow = model.substring(0 , model.indexOf('-'));
        CreateGroup.firstGroupUser(userfollow);
        Block.blockUser(userfollow);
        try {
            Class.forName("com.mysql.cj.jdbc.Driver").newInstance();
            String url = "jdbc:mysql://localhost/game?user=root&password=13821382sS";
            Connection connect = DriverManager.getConnection(url);
            Statement state = connect.createStatement();
            String query = "CREATE TABLE %s ( following varchar(255) , followers varchar(255) ) ";
            String username = model.substring(0 , model.indexOf('-'));
            query = String.format(query , username );
            state.execute(query);
            query = "INSERT INTO all_user VALUES ('%s')";
            query = String.format(query , username);
            state.execute(query);
            query = "CREATE TABLE %s (tweets varchar(255) , time varchar (40) )";
            String table_name = username + "_tweet";
            query = String.format(query, table_name);
            state.execute(query);
            query = "CREATE TABLE %s (timeline varchar(255))";
            String temp = userfollow+"_timeline";
            query = String.format(query , temp);
            state.execute(query);
            state.close();
            connect.close();
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (InstantiationException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        }

    }
    public static void writeToForgetPassword(String model ) throws IOException {
        File user = new File("ForgetPassword.txt");
        // list that holds strings of a file
        List<String> listOfStrings = new ArrayList<String>();
        // load data from file
        BufferedReader bf = new BufferedReader(new FileReader("ForgetPassword.txt"));
        // read entire line as string
        String line = bf.readLine();
        // checking for end of file
        while (line != null) {
            listOfStrings.add(line);
            line = bf.readLine();
        }
        bf.close();
        String[] data = listOfStrings.toArray(new String[0]);

        FileWriter writer = new FileWriter("ForgetPassword.txt");
        for(int i=0 ; i<data.length ; i++)
            writer.append(data[i]+"\n");
        writer.append(model+"\n");
        writer.close();
    }
    public static String[] dataForget () throws IOException {
        File user = new File("ForgetPassword.txt");
        // list that holds strings of a file
        List<String> listOfStrings = new ArrayList<String>();
        // load data from file
        BufferedReader bf = new BufferedReader(new FileReader("ForgetPassword.txt"));
        // read entire line as string
        String line = bf.readLine();
        // checking for end of file
        while (line != null) {
            listOfStrings.add(line);
            line = bf.readLine();
        }
        bf.close();
        String[] data = listOfStrings.toArray(new String[0]);
        return data;
    }
    public static void replaceUser (String newInfo , String username2) throws IOException {
        File user = new File("User.txt");
        // list that holds strings of a file
        List<String> listOfStrings = new ArrayList<String>();
        // load data from file
        BufferedReader bf = new BufferedReader(new FileReader("User.txt"));
        // read entire line as string
        String line = bf.readLine();
        // checking for end of file
        while (line != null) {
            listOfStrings.add(line);
            line = bf.readLine();
        }
        bf.close();
        String[] data = listOfStrings.toArray(new String[0]);

        FileWriter writer = new FileWriter("User.txt");
        for(int i=0 ; i<data.length ; i++) {
            if(!data[i].startsWith(username2))
               writer.append(data[i] + "\n");
        }
        writer.append(newInfo+"\n");
        writer.close();
    }
}
