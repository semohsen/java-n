package modle;

import java.io.*;
import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.Date;

public class CreateGroup {
    public static int messageIdGroup = 1000;

    public static void createGroup(String owner, String nameGroup,
                                   ArrayList<String> users, ArrayList<String> admins, String idGroup) {

        String timeStamp = new SimpleDateFormat("yyyy.MM.dd.HH.mm").format(new Date());
        timeStamp = timeStamp.replace('.', '_');

        String namegroup = ("group_" + nameGroup).toLowerCase(Locale.ROOT);

        try {
            Class.forName("com.mysql.cj.jdbc.Driver").newInstance();
            String url = "jdbc:mysql://localhost/game?user=root&password=13821382sS";
            Connection connect = DriverManager.getConnection(url);
            Statement state = connect.createStatement();
            String query = "CREATE TABLE %s (idGroup varchar(255),users varchar(255) ,admins varchar(255)" +
                    " ,messages varchar(255),messageidgroup varchar(255) , banuser varchar(255)," +
                    " timeMessage varchar(255))";
            query = String.format(query, namegroup);
            state.execute(query);
            query = "INSERT INTO %s (admins) VALUES ('%s')";
            query = String.format(query, namegroup, owner);
            state.execute(query);
            query = "INSERT INTO %s (idGroup) VALUES ('%s')";
            query = String.format(query, namegroup, idGroup);
            state.execute(query);
            query = "INSERT INTO %s values ('%s' )" ;
            String temp = "groupu_" + owner ;
            query = String.format(query , temp , nameGroup);
            state.execute(query);
            state.close();
            connect.close();
        } catch (SQLException | ClassNotFoundException | InstantiationException |
                IllegalAccessException e) {
            e.printStackTrace();
        }
    }

    public static void addUser(String nameGroup, String user) {
        String namegroup = ("group_" + nameGroup).toLowerCase(Locale.ROOT);
        try {
            Class.forName("com.mysql.cj.jdbc.Driver").newInstance();
            String url = "jdbc:mysql://localhost/game?user=root&password=13821382sS";
            Connection connect = DriverManager.getConnection(url);
            Statement state = connect.createStatement();
            Date date = new Date();
            String query = "INSERT INTO %s (users) VALUES ('%s')";
            query = String.format(query, namegroup, user);
            state.execute(query);
            state.close();
            connect.close();

            System.out.format("you add %s ", user + " to users\n");
        } catch (SQLException | ClassNotFoundException | InstantiationException |
                IllegalAccessException e) {
            e.printStackTrace();
        }
    }

    public static boolean adminIsMember(String admin, String nameGroup) {
        String namegroup = ("group_" + nameGroup).toLowerCase(Locale.ROOT);
        try {
            Class.forName("com.mysql.cj.jdbc.Driver").newInstance();
            String url = "jdbc:mysql://localhost/game?user=root&password=13821382sS";
            Connection connect = DriverManager.getConnection(url);
            Statement state = connect.createStatement();
            String query = "select users from %s ";
            query = String.format(query, namegroup);
            ResultSet rs = state.executeQuery(query);
            ResultSetMetaData rsmd = rs.getMetaData();
            int columnsNumber = rsmd.getColumnCount();
            int counter = 1;
            boolean print = false;
            while (rs.next()) {
                //Print one row
                for (int i = 1; i <= columnsNumber; i++) {
                    if (rs.getString(i) != null) {
                        String sent = rs.getString(i);
                        if (Objects.equals(admin, sent)) {
                            print = true;
                            return print;
                        }
                    }
                }
                counter++;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (InstantiationException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        }
        return false;
    }

    public static void addAdmin(String owner, String nameGroup, String admin) {
        String namegroup = ("group_" + nameGroup).toLowerCase(Locale.ROOT);
        try {
            Class.forName("com.mysql.cj.jdbc.Driver").newInstance();
            String url = "jdbc:mysql://localhost/game?user=root&password=13821382sS";
            Connection connect = DriverManager.getConnection(url);
            Statement state = connect.createStatement();
            Date date = new Date();
            String query = "INSERT INTO %s (admins) VALUES ('%s')";
            query = String.format(query, namegroup, admin);
            state.execute(query);
            state.close();
            connect.close();

            System.out.format("you add %s ", admin + " to admins\n");
        } catch (SQLException | ClassNotFoundException | InstantiationException |
                IllegalAccessException e) {
            e.printStackTrace();
        }
    }

    public static void showAdmins(String nameGroup) {
        String namegroup = ("group_" + nameGroup).toLowerCase(Locale.ROOT);
        try {
            Class.forName("com.mysql.cj.jdbc.Driver").newInstance();
            String url = "jdbc:mysql://localhost/game?user=root&password=13821382sS";
            Connection connect = DriverManager.getConnection(url);
            Statement state = connect.createStatement();
            String query = "select admins from %s";
            query = String.format(query, namegroup);
            state.execute(query);

            ResultSet rs = state.executeQuery(query);
            ResultSetMetaData rsmd = rs.getMetaData();
            int columnsNumber = rsmd.getColumnCount();
            System.out.println("---------------------------------------------------------------");
            int counter = 1;
            boolean print = false;
            while (rs.next()) {
                //Print one row
                String sender;
                for (int i = 1; i <= columnsNumber; i++) {
                    if (rs.getString(i) != null) {
                        String sent = rs.getString(i);
                        System.out.print(counter + " - " + sent + " \n"); //Print one element of a row
                        print = true;
                        counter++;
                    }
                }
            }
            if (!print)
                System.out.println("NO ADMIN FOUND ");
            System.out.println("---------------------------------------------------------------");

        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (InstantiationException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        }
    }

    public static void showUsers(String nameGroup) {
        String namegroup = ("group_" + nameGroup).toLowerCase(Locale.ROOT);
        try {
            Class.forName("com.mysql.cj.jdbc.Driver").newInstance();
            String url = "jdbc:mysql://localhost/game?user=root&password=13821382sS";
            Connection connect = DriverManager.getConnection(url);
            Statement state = connect.createStatement();
            String query = "select users from %s";
            query = String.format(query, namegroup);
            state.execute(query);

            ResultSet rs = state.executeQuery(query);
            ResultSetMetaData rsmd = rs.getMetaData();
            int columnsNumber = rsmd.getColumnCount();
            System.out.println("---------------------------------------------------------------");
            int counter = 1;
            boolean print = false;
            while (rs.next()) {
                //Print one row
                String sender;
                for (int i = 1; i <= columnsNumber; i++) {
                    if (rs.getString(i) != null) {
                        String sent = rs.getString(i);
                        System.out.print(counter + " - " + sent + " \n"); //Print one element of a row
                        print = true;
                        counter++;
                    }
                }
            }
            if (!print)
                System.out.println("NO USERS FOUND ");
            System.out.println("---------------------------------------------------------------");

        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (InstantiationException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        }
    }

    public static void showChats(String nameGroup) {
        String namegroup = ("group_" + nameGroup).toLowerCase(Locale.ROOT);
        try {
            Class.forName("com.mysql.cj.jdbc.Driver").newInstance();
            String url = "jdbc:mysql://localhost/game?user=root&password=13821382sS";
            Connection connect = DriverManager.getConnection(url);
            Statement state = connect.createStatement();
            String query = "select messages from %s";
            query = String.format(query, namegroup);
            state.execute(query);

            ResultSet rs = state.executeQuery(query);
            ResultSetMetaData rsmd = rs.getMetaData();
            int columnsNumber = rsmd.getColumnCount();
            System.out.println("---------------------------------------------------------------");
            int counter = 1;
            boolean print = false;
            while (rs.next()) {
                //Print one row
                String sender;
                for (int i = 1; i <= columnsNumber; i++) {
                    if (rs.getString(i) != null) {
                        String sent = rs.getString(i);
                        System.out.print(counter + " - " + sent + " "); //Print one element of a row
                        print = true;
                    }
                }
                counter++;
                System.out.println();
            }
            if (!print)
                System.out.println("NO CHAT FOUND ");
            System.out.println("---------------------------------------------------------------");

        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (InstantiationException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        }
    }

   public static void firstGroupUser(String username) {
        String firstGroupUser = ("groupu_" + username);
        firstGroupUser = firstGroupUser.toLowerCase();
        //String firstGroupUser="group_user_";
        try {
            Class.forName("com.mysql.cj.jdbc.Driver").newInstance();
            String url = "jdbc:mysql://localhost/game?user=root&password=13821382sS";
            Connection connect = DriverManager.getConnection(url);
            Statement state = connect.createStatement();
            String query = "CREATE TABLE %s ( amount varchar(40) ) ; ";
            query = String.format(query, firstGroupUser);
            state.execute(query);
            state.close();
            connect.close();
        } catch (SQLException | ClassNotFoundException | InstantiationException |
                IllegalAccessException e) {
            e.printStackTrace();
        }
    }



    public static void addGroupUser(String username, String GroupName, String idgroup) {
        String namegroup = ("group_" + GroupName).toLowerCase(Locale.ROOT);
        // String firstGroupUser="group_user_"+username;
        String firstGroupUser = ("groupu_" + username).toLowerCase(Locale.ROOT);
        try {
            Class.forName("com.mysql.cj.jdbc.Driver").newInstance();
            String url = "jdbc:mysql://localhost/game?user=root&password=13821382sS";
            Connection connect = DriverManager.getConnection(url);
            Statement state = connect.createStatement();
            String query = "INSERT INTO %s VAlUE ('%s')";
            query = String.format(query, firstGroupUser, namegroup);
            state.execute(query);
            state.close();
            connect.close();
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (InstantiationException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        }
    }

    public static void showMyGroup(String username) {
        String firstGroupUser = ("groupu_" + username).toLowerCase(Locale.ROOT);
        try {
            Class.forName("com.mysql.cj.jdbc.Driver").newInstance();
            String url = "jdbc:mysql://localhost/game?user=root&password=13821382sS";
            Connection connect = DriverManager.getConnection(url);
            Statement state = connect.createStatement();
            String query = "select amount from %s ";
            query = String.format(query, firstGroupUser);
            ResultSet rs = state.executeQuery(query);
            ResultSetMetaData rsmd = rs.getMetaData();
            int columnsNumber = rsmd.getColumnCount();
            // Iterate through the data in the result set and display it.
            System.out.println("---------------------------------------------------------------");
            int counter = 1;
            boolean print = false;
            while (rs.next()) {
                //Print one row
                for (int i = 1; i <= columnsNumber; i++) {
                    if (rs.getString(i) != null) {
                        String sent = rs.getString(i);
                        System.out.print(counter + "-" + sent + " "); //Print one element of a row
                        print = true;
                        counter++;
                        System.out.println();
                    }
                }
            }
            if (!print)
                System.out.println("NO GROUP FOUND ");
            System.out.println("---------------------------------------------------------------");
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (InstantiationException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        }
    }

    public static void deleteUser(String nameGroup, String username2) {
        String namegroup = ("group_" + nameGroup).toLowerCase(Locale.ROOT);
        try {
            Class.forName("com.mysql.cj.jdbc.Driver").newInstance();
            String url = "jdbc:mysql://localhost/game?user=root&password=13821382sS";
            Connection connect = DriverManager.getConnection(url);
            Statement state = connect.createStatement();
            Date date = new Date();
            String query = "DELETE FROM %s WHERE users= '%s' ";
            query = String.format(query, namegroup, username2);
            state.execute(query);
            state.close();
            connect.close();

            System.out.format("you delete %s ", username2 + " to users\n");
        } catch (SQLException | ClassNotFoundException | InstantiationException |
                IllegalAccessException e) {
            e.printStackTrace();
        }
    }

    public static void changeNameGroup(String oldnameGroup, String newNameGroup) {
        String oldNamegroup = ("group_" + oldnameGroup).toLowerCase(Locale.ROOT);
        String newNamegroup = ("group_" + newNameGroup).toLowerCase(Locale.ROOT);
        try {
            Class.forName("com.mysql.cj.jdbc.Driver").newInstance();
            String url = "jdbc:mysql://localhost/game?user=root&password=13821382sS";
            Connection connect = DriverManager.getConnection(url);
            Statement state = connect.createStatement();
            Date date = new Date();
            String query = "RENAME TABLE %s TO %s";
            query = String.format(query, oldNamegroup, newNamegroup);
            state.execute(query);
            state.close();
            connect.close();

            System.out.format("you changed name group to %s ", newNamegroup + "\n");
        } catch (SQLException | ClassNotFoundException | InstantiationException |
                IllegalAccessException e) {
            e.printStackTrace();
        }
    }

    public static void banUser(String nameGroup, String username2) {
        String namegroup = ("group_" + nameGroup).toLowerCase(Locale.ROOT);
        try {
            Class.forName("com.mysql.cj.jdbc.Driver").newInstance();
            String url = "jdbc:mysql://localhost/game?user=root&password=13821382sS";
            Connection connect = DriverManager.getConnection(url);
            Statement state = connect.createStatement();
            Date date = new Date();
            String query = "INSERT INTO %s (banuser) VALUES ('%s')";
            query = String.format(query, namegroup, username2);
            state.execute(query);
            state.close();
            connect.close();

            System.out.format("you ban %s ", username2 + "\n");
        } catch (SQLException | ClassNotFoundException | InstantiationException |
                IllegalAccessException e) {
            e.printStackTrace();
        }

    }

    public static boolean checkAdmin(String nameGroup, String username2) {
        String namegroup = ("group_" + nameGroup).toLowerCase(Locale.ROOT);
        try {
            Class.forName("com.mysql.cj.jdbc.Driver").newInstance();
            String url = "jdbc:mysql://localhost/game?user=root&password=13821382sS";
            Connection connect = DriverManager.getConnection(url);
            Statement state = connect.createStatement();
            String query = "select admins from %s ";
            query = String.format(query, namegroup);
            ResultSet rs = state.executeQuery(query);
            ResultSetMetaData rsmd = rs.getMetaData();
            int columnsNumber = rsmd.getColumnCount();
            int counter = 1;
            boolean print = false;
            while (rs.next()) {
                //Print one row
                for (int i = 1; i <= columnsNumber; i++) {
                    if (rs.getString(i) != null) {
                        String sent = rs.getString(i);
                        if (Objects.equals(username2, sent)) {
                            print = true;
                            return print;
                        }
                    }
                }
                counter++;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (InstantiationException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        }
        return false;
    }

    public static boolean checkUser(String nameGroup, String username2) {
        String namegroup = ("group_" + nameGroup).toLowerCase(Locale.ROOT);
         try {
             Class.forName("com.mysql.cj.jdbc.Driver").newInstance();
             String url = "jdbc:mysql://localhost/game?user=root&password=13821382sS";
             Connection connect = DriverManager.getConnection(url);
             Statement state = connect.createStatement();
             String query = "select users from %s  ; ";
             query = String.format(query, namegroup);
             ResultSet rs = state.executeQuery(query);
             ResultSetMetaData rsmd = rs.getMetaData();
             int columnsNumber = rsmd.getColumnCount();
             int counter = 1;
             boolean print = false;
             while (rs.next()) {
                 //Print one row
                 for (int i = 1; i <= columnsNumber; i++) {
                     if (rs.getString(i) != null) {
                         String sent = rs.getString(i);
                         if (Objects.equals(username2, sent)) {
                             print = true;
                             return print;
                         }
                     }
                 }
                 counter++;
             }
         } catch (SQLException e) {
             e.printStackTrace();
         } catch (ClassNotFoundException e) {
             e.printStackTrace();
         } catch (InstantiationException e) {
             e.printStackTrace();
         } catch (IllegalAccessException e) {
             e.printStackTrace();
         }
         return false;
    }

    public static boolean checkBanUser(String nameGroup, String username2) {
        String namegroup = ("group_" + nameGroup).toLowerCase(Locale.ROOT);
        try {
            Class.forName("com.mysql.cj.jdbc.Driver").newInstance();
            String url = "jdbc:mysql://localhost/game?user=root&password=13821382sS";
            Connection connect = DriverManager.getConnection(url);
            Statement state = connect.createStatement();
            String query = "select banuser from %s ";
            query = String.format(query, namegroup);
            ResultSet rs = state.executeQuery(query);
            ResultSetMetaData rsmd = rs.getMetaData();
            int columnsNumber = rsmd.getColumnCount();
            int counter = 1;
            boolean print = false;
            while (rs.next()) {
                //Print one row
                for (int i = 1; i <= columnsNumber; i++) {
                    if (rs.getString(i) != null) {
                        String sent = rs.getString(i);
                        if (Objects.equals(username2, sent)) {
                            return true ;
                        }
                    }
                }
                counter++;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (InstantiationException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        }
        return false;
    }

    public static void chatGroup(String nameGroup, String username, String Text) {
        String namegroup = ("group_" + nameGroup).toLowerCase(Locale.ROOT);

        String timeStamp = new SimpleDateFormat("yyyy.MM.dd.HH.mm").format(new Date());
        timeStamp = timeStamp.replace('.', '_');

        try {
            Class.forName("com.mysql.cj.jdbc.Driver").newInstance();
            String url = "jdbc:mysql://localhost/game?user=root&password=13821382sS";
            Connection connect = DriverManager.getConnection(url);
            Statement state = connect.createStatement();
           int MessageId = newId();
            String query = "INSERT INTO %s (messages,messageidgroup,timeMessage) VALUES ('%s','%s','%s')";
            query = String.format(query, namegroup,   username + " : " + Text,MessageId, timeStamp);
            state.execute(query);
            state.close();
            connect.close();
            System.out.format("you send message %s \n", Text);
        } catch (SQLException | ClassNotFoundException | InstantiationException | IllegalAccessException | IOException e) {
            e.printStackTrace();
        }

    }

    public static String findMessageGroup(String nameGroup, String username, int number) {
        String namegroup = ("group_" + nameGroup).toLowerCase(Locale.ROOT);
        try {
            Class.forName("com.mysql.cj.jdbc.Driver").newInstance();
            String url = "jdbc:mysql://localhost/game?user=root&password=13821382sS";
            Connection connect = DriverManager.getConnection(url);
            Statement state = connect.createStatement();
            String query = "select  from %s where ";
            query = String.format(query, namegroup);
            ResultSet rs = state.executeQuery(query);
            ResultSetMetaData rsmd = rs.getMetaData();
            int columnsNumber = rsmd.getColumnCount();
            int counter = 0;
            boolean find = false;
            while (rs.next() && !find) {
                //Print one row
                counter++;
                for (int i = 1; i <= columnsNumber; i++) {
                    if (counter == number) {
                        find = true;
                    }
                }
            }
            if (find)
                return nameGroup;
        } catch (SQLException | ClassNotFoundException | InstantiationException | IllegalAccessException e) {
            e.printStackTrace();
        }
        return nameGroup;
    }


    public static void editMessageGroup(String nameGroup, String username, String oldchat, String newChat) {
        String namegroup = ("group_" + nameGroup).toLowerCase(Locale.ROOT);
        try {
            Class.forName("com.mysql.cj.jdbc.Driver").newInstance();
            String url = "jdbc:mysql://localhost/game?user=root&password=13821382sS";
            Connection connect = DriverManager.getConnection(url);
            Statement state = connect.createStatement();
            Date date = new Date();
            String query = "UPDATE %s SET messages=%s WHERE messages=%s";
            query = String.format(query, namegroup, oldchat, username + " : " + newChat);
            state.execute(query);
            state.close();
            connect.close();

            System.out.format("you edit to %s ", newChat + "\n");
        } catch (SQLException | ClassNotFoundException | InstantiationException |
                IllegalAccessException e) {
            e.printStackTrace();
        }
    }


    public static void deleteMessageGroup(String nameGroup, String username2, String chat) {
        String namegroup = ("group_" + nameGroup).toLowerCase(Locale.ROOT);
        try {
            Class.forName("com.mysql.cj.jdbc.Driver").newInstance();
            String url = "jdbc:mysql://localhost/game?user=root&password=13821382sS";
            Connection connect = DriverManager.getConnection(url);
            Statement state = connect.createStatement();
            Date date = new Date();
            String query = "DELETE FROM %s WHERE messages=%s";
            query = String.format(query, namegroup, chat);
            state.execute(query);
            state.close();
            connect.close();

            System.out.format("you delete %s ", chat + "\n");
        } catch (SQLException | ClassNotFoundException | InstantiationException |
                IllegalAccessException e) {
            e.printStackTrace();
        }
    }

    public static int newId() throws IOException {
        int messageId1;
        File user = new File("messageId.txt");
        // list that holds strings of a file
        List<String> listOfStrings = new ArrayList<String>();
        // load data from file
        BufferedReader bf = new BufferedReader(new FileReader("messageId.txt"));
        // read entire line as string
        int line = Integer.parseInt(bf.readLine());
        // checking for end of file

        bf.close();
        messageId1 = line + 1;
        String data = String.valueOf(messageId1);

        FileWriter w = new FileWriter("messageId.txt");
        // for(int i=0 ; i<data.length ; i++)
        w.write(data);
        // writer.append(model+"\n");
        w.close();
        return messageId1;
    }
}


//login
//Ali
//Ali12345!
//create group
//ee1401
//12832

