package modle;

import java.sql.*;

public class Like {
    public static void like(String username , int tweet_number, String table)
    {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver").newInstance();
            String url = "jdbc:mysql://localhost/game?user=root&password=13811351";
            Connection connect = DriverManager.getConnection(url);
            Statement state = connect.createStatement();
            String query = "INSERT INTO %s VALUES ('%s')";
            query = String.format(query,table , username);
            state.execute(query);
            state.close();
            connect.close();
            System.out.println("you Liked .");
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (InstantiationException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        }
    }
    public static void Dislike(String username , int tweet_number, String table)
    {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver").newInstance();
            String url = "jdbc:mysql://localhost/game?user=root&password=13811351";
            Connection connect = DriverManager.getConnection(url);
            Statement state = connect.createStatement();
            String query = "DELETE FROM %s WHERE user_like ='%s'";
            query = String.format(query,table , username);
            state.execute(query);
            state.close();
            connect.close();
            System.out.println("you DisLiked .");
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (InstantiationException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        }
    }
    public static void Showlike(String username , int tweet_number, String table)
    {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver").newInstance();
            String url = "jdbc:mysql://localhost/game?user=root&password=13811351";
            Connection connect = DriverManager.getConnection(url);
            Statement state = connect.createStatement();
            String query = "select * from %s ";
            query = String.format(query , table);
            ResultSet rs = state.executeQuery(query);
            ResultSetMetaData rsmd = rs.getMetaData();
            int columnsNumber = rsmd.getColumnCount();
            // Iterate through the data in the result set and display it.
            System.out.println("---------------------------------------------------------------");
            int counter = 1 ;
            boolean print = false ;
            while (rs.next()) {
                //Print one row
                for(int i = 1 ; i <= columnsNumber; i++){
                    if(rs.getString(i)!=null) {
                        String sent = rs.getString(i);
                        System.out.print( sent + " "); //Print one element of a row
                        print = true ;
                    }
                }
                counter++;
                System.out.println();//Move to the next line to print the next row.
            }
            if(!print)
                System.out.println("NO LIKE FOUND ");
            System.out.println("---------------------------------------------------------------");
        }
        catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (InstantiationException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        }
    }
    public static void AmountOfLike(String username , int tweet_number , String table )
    {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver").newInstance();
            String url = "jdbc:mysql://localhost/game?user=root&password=13811351";
            Connection connect = DriverManager.getConnection(url);
            Statement state = connect.createStatement();
            String query = "select * from %s ";
            query = String.format(query , table);
            ResultSet rs = state.executeQuery(query);
            ResultSetMetaData rsmd = rs.getMetaData();
            int columnsNumber = rsmd.getColumnCount();
            // Iterate through the data in the result set and display it.
            System.out.println("---------------------------------------------------------------");
            int counter = 0 ;
            boolean print = false ;
            while (rs.next()) {
                //Print one row
                for(int i = 1 ; i <= columnsNumber; i++){
                    if(rs.getString(i)!=null) {
                        String sent = rs.getString(i);
                        print = true ;
                    }
                }
                counter++;
            }
            if(!print)
                System.out.println("NO LIKE FOUND ");
            else
                System.out.format("%s Like is Found \n" , counter);
            System.out.println("---------------------------------------------------------------");
        }
        catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (InstantiationException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        }
    }

}
