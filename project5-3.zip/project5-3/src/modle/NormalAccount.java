package modle;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import controller.Manager;

public class NormalAccount {

    private String name;
    private ArrayList<String> blockedAccounts = new ArrayList<String>();
    Manager manager;

    public NormalAccount(String name) {
        this.name=name;
    }

    public String getName() {
        return name;
    }

    public static void processCreateNormalAccounts(String username) {
        String account="account";
        String NormalAccount="Normal";
        try {
            Class.forName("com.mysql.cj.jdbc.Driver").newInstance();
            String url = "jdbc:mysql://localhost/game?user=root&password=13821382sS";
            Connection connect = DriverManager.getConnection(url);
            Statement state = connect.createStatement();
            String query = "INSERT INTO account Values ('%s', '%s')";
            query = String.format(query , username , NormalAccount);
            state.execute(query);
            state.close();
            connect.close();
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (InstantiationException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        }
        System.out.println("Created Normal Accounts");
    }


    public void BlockedUser(String name,String blockedName) {
        try {
            blockedAccounts.add(String.valueOf(manager.getNormalAccountByNormalAccountName(blockedName)));
        }
        catch (NullPointerException e) {
            System.out.println("This Name Doesn't Exit");
        }
    }

}
