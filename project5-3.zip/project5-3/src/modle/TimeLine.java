package modle;

import java.sql.*;
import java.util.ArrayList;

public class TimeLine {

    public static void ShowTimeLine(String username)
    {

        try {
            Class.forName("com.mysql.cj.jdbc.Driver").newInstance();
            String url = "jdbc:mysql://localhost/game?user=root&password=13811351";
            Connection connect = DriverManager.getConnection(url);
            Statement state = connect.createStatement();
            String query = "select timeline from %s";
            String temp = username+"_timeline";
            query = String.format(query , temp);
            ResultSet rs = state.executeQuery(query);
            ResultSetMetaData rsmd = rs.getMetaData();
            int columnsNumber = rsmd.getColumnCount();
            // Iterate through the data in the result set and display it.
            System.out.println("---------------------------------------------------------------");
            ad.showAd();
            System.out.println("---------------------------------------------------------------");
            int counter = 1 ;
            while (rs.next()) {
                //Print one row
                System.out.println("---------------------------------------------------------------");
                for(int i = 1 ; i <= columnsNumber; i++){
                    System.out.print(counter+"-"+rs.getString(i) + " "); //Print one element of a row
                }
                counter++;
                System.out.println();//Move to the next line to print the next row.
                System.out.println("comment        like ");
            }
            System.out.println("---------------------------------------------------------------");
            ad.showAd();
            System.out.println("---------------------------------------------------------------");
        }
        catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (InstantiationException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        }
    }
    public static void Like (String username , int number)
    {

    }
    public static void FindTweet (int number )
    {

    }
}
