package modle;

import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;
import java.util.*;
public class tweet {

    public static void sendTweet (String username)
    {
        Scanner scanner = new Scanner(System.in);
        System.out.println("type your tweet then Enter...");
        String tweet = scanner.nextLine();
        System.out.println("type POST or DELET");
        String temp =scanner.nextLine();
        temp = temp.toLowerCase();
        if(temp.startsWith("post")) {
            String timeStamp = new SimpleDateFormat("yyyy.MM.dd.HH.mm").format(new java.util.Date());
            timeStamp = timeStamp.replace('.' , '_');
            try {
                Class.forName("com.mysql.cj.jdbc.Driver").newInstance();
                String url = "jdbc:mysql://localhost/game?user=root&password=13821382sS";
                Connection connect = DriverManager.getConnection(url);
                Statement state = connect.createStatement();
                String query = "INSERT INTO %s (tweets , time ) VALUES ('%s' , '%s' )";
                String table_name = username + "_tweet";
                query = String.format(query, table_name, tweet , timeStamp);
                state.execute(query);
                //add to timelines
                query = "CREATE TABLE %s (user_like varchar(40))";
                temp ="like_"+username+"_"+timeStamp;
                query = String.format(query , temp);
                state.execute(query);
                state.close();
                connect.close();
                query = "select followers from %s";
                query = String.format(query , username);
                Connection con = DriverManager.getConnection(url);
                Statement sta = con.createStatement();
                ResultSet rs = sta.executeQuery(query);
                ResultSetMetaData rsmd = rs.getMetaData();
                int columnsNumber = rsmd.getColumnCount();
                String timelineadd = username + " : " + tweet ;
                while (rs.next()) {
                    Connection connection = DriverManager.getConnection(url);
                    Statement statement = connection.createStatement();
                    //Print one row
                    for(int i = 1 ; i <= columnsNumber; i++){
                        if(rs.getString(i)!=null) {
                            temp = rs.getString(i) + "_timeline";
                            String order = "insert into %s values ('%s') ";
                            order = String.format(order, temp, timelineadd);
                            statement.execute(order);
                            statement.close();
                            connection.close();
                        }
                    }
                }
                // added

                ///
                System.out.println("your tweet sent . ");
            } catch (SQLException e) {
                e.printStackTrace();
            } catch (ClassNotFoundException e) {
                e.printStackTrace();
            } catch (InstantiationException e) {
                e.printStackTrace();
            } catch (IllegalAccessException e) {
                e.printStackTrace();
            }
        }
        else {
            return;
        }
    }
    public static void deletTweet (String username , int number ) {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver").newInstance();
            String url = "jdbc:mysql://localhost/game?user=root&password=13821382sS";
            Connection connect = DriverManager.getConnection(url);
            Statement state = connect.createStatement();
            String query = "select tweets from %s";
            String temp = username+"_tweet";
            query = String.format(query , temp);
            ResultSet rs = state.executeQuery(query);
            ResultSetMetaData rsmd = rs.getMetaData();
            int columnsNumber = rsmd.getColumnCount();
            int counter=1;
            String tweet ="";
            while (rs.next()) {
                if(counter==number)
                {
                    tweet = rs.getString(1);
                    break;
                }
                else
                    counter++;
            }
            query = "delete from %s where tweets='%s'";
            query = String.format(query , temp , tweet);
            state.execute(query);
            state.close();
            connect.close();
            //delete from timelines
            query = "select followers from %s";
            query = String.format(query , username);
            Connection con = DriverManager.getConnection(url);
            Statement sta = con.createStatement();
            ResultSet rss = sta.executeQuery(query);
            ResultSetMetaData rsmdd = rss.getMetaData();
            int columnsNumberr = rsmdd.getColumnCount();
            String timelineadd = username + ": " + tweet ;
            while (rss.next()) {
                Connection connection = DriverManager.getConnection(url);
                Statement statement = connection.createStatement();
                //Print one row
                for(int i = 1 ; i <= columnsNumberr; i++){
                    if(rss.getString(i)!=null) {
                        temp = rss.getString(i) + "_timeline";
                        String order = "delete from %s where timeline='%s'";
                        order = String.format(order, temp, timelineadd);
                        statement.execute(order);
                        statement.close();
                        connection.close();
                    }
                }
            }
            // added


            System.out.println("your tweet is deleted . ");
        }
        catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (InstantiationException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        }
    }
    public static void Showtweet (String username) {
    try {
        Class.forName("com.mysql.cj.jdbc.Driver").newInstance();
        String url = "jdbc:mysql://localhost/game?user=root&password=13821382sS";
        Connection connect = DriverManager.getConnection(url);
        Statement state = connect.createStatement();
        String query = "select tweets from %s";
        String temp = username+"_tweet";
        query = String.format(query , temp);
        ResultSet rs = state.executeQuery(query);
        ResultSetMetaData rsmd = rs.getMetaData();
        int columnsNumber = rsmd.getColumnCount();
        // Iterate through the data in the result set and display it.
        System.out.println("---------------------------------------------------------------");
        int counter = 1 ;
        while (rs.next()) {
            //Print one row
            for(int i = 1 ; i <= columnsNumber; i++){
                System.out.print(counter+"-"+rs.getString(i) + " "); //Print one element of a row
            }
            counter++;
            System.out.println();//Move to the next line to print the next row.
        }
        System.out.println("---------------------------------------------------------------");
    }
    catch (SQLException e) {
        e.printStackTrace();
    } catch (ClassNotFoundException e) {
        e.printStackTrace();
    } catch (InstantiationException e) {
        e.printStackTrace();
    } catch (IllegalAccessException e) {
        e.printStackTrace();
    }
    }
}
