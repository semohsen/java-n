package modle;

import java.sql.*;
import java.util.Scanner;

public class ad extends tweet{

    public static int count_ad = 0 ;
    public static int print_ad = 1 ;
    public static void sendAd (String username )
    {
        boolean check = checkAccount(username);
        if(check)
        {
            System.out.println("send your ad text : ");
            Scanner scanner = new Scanner(System.in);
            String input = scanner.nextLine();
            input = "AD : " + input  ;
            try {
                Class.forName("com.mysql.cj.jdbc.Driver").newInstance();
                String url = "jdbc:mysql://localhost/game?user=root&password=13811351";
                Connection connect = DriverManager.getConnection(url);
                Statement state = connect.createStatement();
                String query = "INSERT INTO ad values ('%s') ";
                query =String.format(query , input);
                state.execute(query);
                state.close();
                connect.close();
                System.out.println("your ad sent . ");
            }
            catch (SQLException e) {
                e.printStackTrace();
            } catch (ClassNotFoundException e) {
                e.printStackTrace();
            } catch (InstantiationException e) {
                e.printStackTrace();
            } catch (IllegalAccessException e) {
                e.printStackTrace();
            }
            }
        else {
            System.out.println("you can't send ad text .");
        }
    }
    public static void showAd ()
    {
        try {
            amount_ad();
            Class.forName("com.mysql.cj.jdbc.Driver").newInstance();
            String url = "jdbc:mysql://localhost/game?user=root&password=13811351";
            Connection connect = DriverManager.getConnection(url);
            Statement state = connect.createStatement();
            String query = "select ad from ad";
            query = String.format(query);
            ResultSet rs = state.executeQuery(query);
            ResultSetMetaData rsmd = rs.getMetaData();
            int columnsNumber = rsmd.getColumnCount();
            int counter =1 ;
            if(print_ad==count_ad+1)
                print_ad=1;
            while (rs.next()) {
                if(counter==print_ad) {
                    for (int i = 1; i <= columnsNumber; i++) {
                        System.out.println(rs.getString(i));
                        print_ad++;
                        return;
                    }
                }
                else
                    counter++;
            }
        }
        catch (SQLException e) {
                e.printStackTrace();
            } catch (ClassNotFoundException e) {
                e.printStackTrace();
            } catch (InstantiationException e) {
                e.printStackTrace();
            } catch (IllegalAccessException e) {
                e.printStackTrace();
            }
    }
    public static boolean checkAccount (String username)
    {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver").newInstance();
            String url = "jdbc:mysql://localhost/game?user=root&password=13811351";
            Connection connect = DriverManager.getConnection(url);
            Statement state = connect.createStatement();
            String query = "select account from account where username='%s'";
            query = String.format(query , username);
            ResultSet rs = state.executeQuery(query);
            ResultSetMetaData rsmd = rs.getMetaData();
            int columnsNumber = rsmd.getColumnCount();
            String kind = "" ;
            while (rs.next()) {
                //Print one row
                for(int i = 1 ; i <= columnsNumber; i++){
                  kind = rs.getString(i);
                }
            }
            if(kind.equals("Business"))
            {
                return true ;
            }
            else
                return false ;
        }
        catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (InstantiationException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        }
        return false ;
    }
    public static void amount_ad ()
    {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver").newInstance();
            String url = "jdbc:mysql://localhost/game?user=root&password=13811351";
            Connection connect = DriverManager.getConnection(url);
            Statement state = connect.createStatement();
            String query = "select ad from ad";
            query = String.format(query);
            ResultSet rs = state.executeQuery(query);
            ResultSetMetaData rsmd = rs.getMetaData();
            int columnsNumber = rsmd.getColumnCount();
            int counter = 0;
            while (rs.next()) {
                counter++;
            }
            count_ad = counter ;
        }
        catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (InstantiationException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        }
    }
}
