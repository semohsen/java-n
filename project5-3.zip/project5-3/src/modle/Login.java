package modle;

import view.InputProcessor;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;


public class Login extends UserInfo {

    public static void loginuser (String login) throws IOException, SQLException, ClassNotFoundException, InstantiationException, IllegalAccessException {
        int fasele = login.indexOf("-");
        String username = login.substring(0 , fasele);
        File user = new File("User.txt");
            // list that holds strings of a file
            List<String> listOfStrings = new ArrayList<String>();
            // load data from file
            BufferedReader bf = new BufferedReader(new FileReader("User.txt"));
            // read entire line as string
            String line = bf.readLine();
            // checking for end of file
            while (line != null) {
                listOfStrings.add(line);
                line = bf.readLine();
            }
            bf.close();
            String[] data = listOfStrings.toArray(new String[0]);

        for(int i=0 ; i<data.length ; i++)
        {
            if(data[i].equals(login)) {
                System.out.println("You Are Login ...");
                InputProcessor.loginRun(username);
                return;
            }
        }
            boolean finduser = false ;
            for(int x=0 ; x<data.length ; x++)
            {
                String temp = data[x];
                if(temp.startsWith(username))
                    finduser = true ;
            }
            if(finduser)
                System.out.println("PassWord is Incorrect...");
            else
                System.out.println("User does not found ...");
    }
}
