package modle;

import java.io.*;
import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.Date;

import static modle.comment.Timetweet;

public class PrivateChat {

    static int MessageId;
    public static String answer = "";

    public static void startPrivateChat(String username,String username2,
                          String privateChatText) {
        String timeStamp = new SimpleDateFormat("yyyy.MM.dd.HH.mm").format(new Date());
        timeStamp = timeStamp.replace('.' , '_');
        int a= username.compareTo(username2);
        String nameChat;
        if(a>0){
            nameChat="privateChat_"+username+"_"+username2;
        }
        else {
            nameChat="privateChat_"+username2+"_"+username;
        }
        nameChat=nameChat.toLowerCase(Locale.ROOT);

        try {
            Class.forName("com.mysql.cj.jdbc.Driver").newInstance();
            String url = "jdbc:mysql://localhost/game?user=root&password=13821382sS";
            Connection connect = DriverManager.getConnection(url);
            Statement state = connect.createStatement();
            String query = "CREATE TABLE %s (messageId varchar(255) ," +
       " %s varchar(255) , %s varchar(255),timeMessage varchar(255))";
            query = String.format(query,nameChat,username,username2);
            state.execute(query);
            state.close();
            connect.close();
        } catch (SQLException | ClassNotFoundException | InstantiationException |
                IllegalAccessException e) {
            e.printStackTrace();
        }
        try {
            Class.forName("com.mysql.cj.jdbc.Driver").newInstance();
            String url = "jdbc:mysql://localhost/game?user=root&password=13821382sS";
            Connection connect = DriverManager.getConnection(url);
            Statement state = connect.createStatement();
           MessageId= newId();
            String query = "INSERT INTO %s (messageId,%s,timeMessage) VALUES (%s,'%s','%s')";
            query = String.format(query,nameChat,username,MessageId,username+" : "+ privateChatText, timeStamp);
            state.execute(query);
            state.close();
            connect.close();

            System.out.format("you send message %s \n", privateChatText);
        } catch (SQLException | ClassNotFoundException | InstantiationException | IllegalAccessException | IOException e) {
            e.printStackTrace();
        }
    }

    public static void privateChat(String username,String username2,String privateChatText) {
        int a= username.compareTo(username2);
        String nameChat;
        if(a>0){
        nameChat="privateChat_"+username+"_"+username2;
     }
     else {
           nameChat="privateChat_"+username2+"_"+username;
        }

        String timeStamp = new SimpleDateFormat("yyyy.MM.dd.HH.mm").format(new Date());
        timeStamp = timeStamp.replace('.' , '_');

        try {
            Class.forName("com.mysql.cj.jdbc.Driver").newInstance();
            String url = "jdbc:mysql://localhost/game?user=root&password=13821382sS";
            Connection connect = DriverManager.getConnection(url);
            Statement state = connect.createStatement();
            MessageId= newId();
                String query = "INSERT INTO %s (messageId,%s,timeMessage) VALUES ('%s','%s','%s')";
                query = String.format(query, nameChat ,username ,MessageId,username+" : "+  privateChatText, timeStamp);
                state.execute(query);
            state.close();
            connect.close();
            System.out.format("you send message %s \n", privateChatText);
        } catch (SQLException | ClassNotFoundException | InstantiationException | IllegalAccessException | IOException e) {
            e.printStackTrace();
        }
    }

    public static void ShowChat(String username ,String username2) {
        int a= username.compareTo(username2);
        String nameChat;
        if(a>0){
            nameChat="privateChat_"+username+"_"+username2;
        }
        else {
            nameChat="privateChat_"+username2+"_"+username;
        }
        try {
            Class.forName("com.mysql.cj.jdbc.Driver").newInstance();
            String url = "jdbc:mysql://localhost/game?user=root&password=13821382sS";
            Connection connect = DriverManager.getConnection(url);
            Statement state = connect.createStatement();
            String query = "select %s,%s from %s";
            query = String.format(query ,username,username2,nameChat );
            state.execute(query);

            ResultSet rs = state.executeQuery(query);
            ResultSetMetaData rsmd = rs.getMetaData();
            int columnsNumber = rsmd.getColumnCount();
            // Iterate through the data in the result set and display it.
            System.out.println("---------------------------------------------------------------");
            int counter = 1 ;
            boolean print = false ;
            while (rs.next()) {
                //Print one row
                String sender;
                for(int i = 1 ; i <= columnsNumber; i++){
                    if(rs.getString(i)!=null) {
                        String sent = rs.getString(i);
//                        if (){
//                            sender=
//                        }
                        System.out.print(counter + " - " + sent + " "); //Print one element of a row
                        print = true ;
                    }
                }
                counter++;
                System.out.println();//Move to the next line to print the next row.
            }
            if(!print)
                System.out.println("NO message FOUND ");
            System.out.println("---------------------------------------------------------------");

        }
        catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (InstantiationException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        }
    }

    public static String findMessageForward(String username, String username2,String number) {
        int a = username.compareTo(username2);
        String nameChat;
        if (a > 0) {
            nameChat = "privateChat_" + username + "_" + username2;
        } else {
            nameChat = "privateChat_" + username2 + "_" + username;
        }
        try {
            Class.forName("com.mysql.cj.jdbc.Driver").newInstance();
            String url = "jdbc:mysql://localhost/game?user=root&password=13821382sS";
            Connection connect = DriverManager.getConnection(url);
            Statement state = connect.createStatement();
            String query = "select %s,%s from %s";
            query = String.format(query, username, username2, nameChat);
            state.execute(query);

            ResultSet rs = state.executeQuery(query);
            ResultSetMetaData rsmd = rs.getMetaData();
            int columnsNumber = rsmd.getColumnCount();
            // Iterate through the data in the result set and display it.
            boolean print = false;
            while (rs.next()) {
                // for(int i = 1 ; i <= columnsNumber; i++){
                if (rs.getString(number) != null) {
                    String sent = rs.getString(number);
                    if (sent.length() < 15) {
                        sent = sent;
                    } else {
                        sent = sent.substring(0, 14);
                    }
                    return sent;
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (InstantiationException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        }
        return "NO message FOUND ";
    }

    public static String findMessage(String username, String username2, int number)
    {
        int a = username.compareTo(username2);
        String nameChat;
        if (a > 0) {
            nameChat = "privateChat_" + username + "_" + username2;
        } else {
            nameChat = "privateChat_" + username2 + "_" + username;
        }
        try {
            Class.forName("com.mysql.cj.jdbc.Driver").newInstance();
            String url = "jdbc:mysql://localhost/game?user=root&password=13821382sS";
            Connection connect = DriverManager.getConnection(url);
            Statement state = connect.createStatement();
            String query = "select %s,%s from %s";
            query = String.format(query, username, username2, nameChat);
            state.execute(query);

            ResultSet rs = state.executeQuery(query);
            ResultSetMetaData rsmd = rs.getMetaData();
            int columnsNumber = rsmd.getColumnCount();
            // Iterate through the data in the result set and display it.
            boolean print = false;
            while (rs.next()) {
                // for(int i = 1 ; i <= columnsNumber; i++){
                if (rs.getString(number) != null) {
                    String sent = rs.getString(number);
                    if (sent.length() < 15) {
                        sent = sent;
                    } else {
                        sent = sent.substring(0, 14);
                    }
                    return sent;
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (InstantiationException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        }
        return "NO message FOUND ";
    }


    public static void editMessage(String username,String username2,String oldchat,String newChat){
        int a= username.compareTo(username2);
        String nameChat;
        if(a>0){
            nameChat="privateChat_"+username+"_"+username2;
        }
        else {
            nameChat="privateChat_"+username2+"_"+username;
        }
        try {
            Class.forName("com.mysql.cj.jdbc.Driver").newInstance();
            String url = "jdbc:mysql://localhost/game?user=root&password=13821382sS";
            Connection connect = DriverManager.getConnection(url);
            Statement state = connect.createStatement();
            Date date = new Date();
            String query = "UPDATE %s SET %s=%s WHERE %s=%s";
            query = String.format(query,nameChat,username,oldchat,username,username+" : "+newChat);
            state.execute(query);
            state.close();
            connect.close();

            System.out.format("you update %s ", nameChat+"\n");
        } catch (SQLException | ClassNotFoundException | InstantiationException |
                IllegalAccessException e) {
            e.printStackTrace();
        }
    }


    public static void deleteMessage(String username,String username2,String chat){
        int a= username.compareTo(username2);
        String nameChat;
        if(a>0){
            nameChat="privateChat_"+username+"_"+username2;
        }
        else {
            nameChat="privateChat_"+username2+"_"+username;
        }
        try {
            Class.forName("com.mysql.cj.jdbc.Driver").newInstance();
            String url = "jdbc:mysql://localhost/game?user=root&password=13821382sS";
            Connection connect = DriverManager.getConnection(url);
            Statement state = connect.createStatement();
            Date date = new Date();
            String query = "DELETE FROM %s WHERE username=%s";
            query = String.format(query,nameChat,chat);
            state.execute(query);
            state.close();
            connect.close();

            System.out.format("you delete %s ", chat+"\n");
        } catch (SQLException | ClassNotFoundException | InstantiationException |
                IllegalAccessException e) {
            e.printStackTrace();
        }
    }

    public static int newId() throws IOException {
        int messageId1;
        File user = new File("messageId.txt");
        // list that holds strings of a file
        List<String> listOfStrings = new ArrayList<String>();
        // load data from file
        BufferedReader bf = new BufferedReader(new FileReader("messageId.txt"));
        // read entire line as string
        int line = Integer.parseInt(bf.readLine());
        // checking for end of file

        bf.close();
        messageId1=line+1;
        String  data = String.valueOf(messageId1);

        FileWriter w = new FileWriter("messageId.txt");
        // for(int i=0 ; i<data.length ; i++)
        w.write(data);
        // writer.append(model+"\n");
        w.close();
        return messageId1;
    }

    }
