package controller;

import modle.BusinessAccount;
import modle.NormalAccount;

import java.util.ArrayList;
import java.util.*;


public class Manager {
ArrayList<String> a=new ArrayList<>();
    private Scanner scanner = new Scanner(System.in);
    private ArrayList<BusinessAccount> businessAccounts;
    private ArrayList<NormalAccount> normalAccounts;

    public Manager() {
        this.businessAccounts = new ArrayList<>();
        this.normalAccounts = new ArrayList<>();
    }

    private NormalAccount normalAccount;
    private BusinessAccount businessAccount;

    public Manager(NormalAccount normalAccount,BusinessAccount businessAccount) {
        this.businessAccount = businessAccount;
        this.normalAccount=normalAccount;
    }

    public void showNormalsAccount() {
        for (NormalAccount normalAccount : normalAccounts) {
            System.out.println(normalAccount);
        }
    }

    public void showBusinessesAccount() {
        for (BusinessAccount businessAccount : businessAccounts) {
            System.out.println(businessAccount);
        }
    }

    public void processCreateNormalAccounts(NormalAccount normalAccount, String name) {
        //System.out.println(normalAccounts);
        normalAccounts.add(normalAccount);
        //System.out.println(normalAccounts);
        normalAccount.processCreateNormalAccounts(name);
        //System.out.println(name);
    }

    public void processCreateBusinessAccounts(String name) {
        businessAccounts.add(getBusinessAccountByBusinessAccountName(name));
        BusinessAccount businessAccount=new BusinessAccount(name,"",a,a);
            businessAccount.processCreateBusinessAccounts();
    }

    public void accountPrivacy(String name,String number){
        //System.out.println(normalAccounts);
        for (NormalAccount normalAccounti : normalAccounts) {
           // System.out.println(normalAccounti.getNormalAccountName());
            //System.out.println(name);
            if (normalAccounti.getNormalAccountName().equals(name)) {
            normalAccounti.accountPrivacy(number);
            }
        }
    }

    public void InteractionAllowTags(String name,String number){
        for (NormalAccount normalAccount1 : normalAccounts) {
            if (normalAccount1.getNormalAccountName().equals(name)) {
                normalAccount1.allowTag(number);
            }
        }
    }

    public void InteractionResharing(String name,String number){
        for (NormalAccount normalAccount1 : normalAccounts) {
            if (normalAccount1.getNormalAccountName().equals(name)) {
                normalAccount1.resharing(number);
            }
        }
    }

    public void InteractionMessageControllers(String name,String number){
        for (NormalAccount normalAccount1 : normalAccounts) {
            if (normalAccount1.getNormalAccountName().equals(name)) {
                normalAccount1.MessageControllers(number);
            }
        }
    }

    public void InteractionAllowMentionFrom(String name,String number){
        for (NormalAccount normalAccount1 : normalAccounts) {
            if (normalAccount1.getNormalAccountName().equals(name)) {
                normalAccount1.AllowMentionFrom(number);
            }
        }
    }

    public void InteractionBlockedUser(String name,String number){
        for (NormalAccount normalAccount1 : normalAccounts) {
            if (normalAccount1.getNormalAccountName().equals(name)) {
                normalAccount1.BlockedUser(number);
            }
        }
    }

    public NormalAccount getNormalAccountByNormalAccountName(String name) {
        for (NormalAccount normalAccount : normalAccounts) {
            if (normalAccount.getNormalAccountName().equals(name)) {
                return normalAccount;
            }
        }
        return null;
    }

    public BusinessAccount getBusinessAccountByBusinessAccountName(String BusinessAccountName) {
        for (BusinessAccount businessAccount : businessAccounts) {
            if (businessAccount.getBusinessAccountName().equals(BusinessAccountName)) {
                return businessAccount;
            }
        }
        return null;
    }


}
