package view;

import java.util.*;

import controller.Manager;
import modle.BusinessAccount;
import modle.NormalAccount;

public class InputProcessor {
    private Scanner scanner = new Scanner(System.in);
    private Manager manager;
    ArrayList<String> a=new ArrayList<>();
    public InputProcessor(Manager manager) {
        this.manager = manager;
    }

    private void processShowNormalAccounts() {
        manager.showNormalsAccount();
    }

    private void processShowBusinessesAccounts() {
        manager.showBusinessesAccount();
    }

    private void processCreateAccounts() {
        String input;
        System.out.println("chose account type");
        System.out.println("1: normal Account");
        System.out.println("2: business Account");
        System.out.println("exit: exit");
        input = scanner.nextLine();
            if (input.equalsIgnoreCase("1")) {
                manager.processCreateNormalAccounts(new NormalAccount("name", "", a, a), "name");

                while (!input.equalsIgnoreCase("exit")) {
                    System.out.println("Account Privacy:");
                    System.out.println("chose 1: for public account");
                    System.out.println("chose 2: for private account");
                    System.out.println("write exit: for exit");
                    input = scanner.nextLine();
                    manager.accountPrivacy("name", input);
                    // System.out.println("If You Want Exit This Page Write :exit");
                }
                input = "";


                while (!input.equalsIgnoreCase("exit")) {
                    System.out.println("Interaction:");
                    System.out.println("Allow Tags:");
                    System.out.println("chose 1: for Everyone");
                    System.out.println("chose 2: for People You Follow");
                    System.out.println("chose 3: for No One");
                    System.out.println("write exit: for exit");
                    input = scanner.nextLine();
                    manager.InteractionAllowTags("name", input);
                }
                input = "";


                while (!input.equalsIgnoreCase("exit")) {
                    System.out.println("Interaction:");
                    System.out.println("Allow Resharing:");
                    System.out.println("chose 1: for Everyone");
                    System.out.println("chose 2: for People You Follow");
                    System.out.println("chose 3: for No One");
                    System.out.println("write exit: for exit");
                    input = scanner.nextLine();
                    manager.InteractionResharing("name", input);
                }
                input = "";
                while (!input.equalsIgnoreCase("exit")) {
                    System.out.println("Interaction:");
                    System.out.println("Message Controllers:");
                    System.out.println("chose 1: for Your Followers");
                    System.out.println("chose 2: for Everyone");
                    System.out.println("write exit: for exit");
                    input = scanner.nextLine();
                    manager.InteractionMessageControllers("name", input);
                }
                input = "";

                while (!input.equalsIgnoreCase("exit")) {
                    System.out.println("Interaction:");
                    System.out.println("Allow Mention From:");
                    System.out.println("chose 1: for Everyone");
                    System.out.println("chose 3: for No One");
                    System.out.println("write exit: for exit");
                    input = scanner.nextLine();
                    manager.InteractionAllowMentionFrom("name", input);
                }
                input = "";

                while (!input.equalsIgnoreCase("exit")) {
                    System.out.println("Interaction:");
                    System.out.println("Blocked User:");
                    System.out.println("write exit: for exit");
                    input = scanner.nextLine();// name of was Blocked
                    manager.InteractionBlockedUser("name", input);
                }
                input = "";
            }

            else if (input.equalsIgnoreCase("2")) {
                manager.processCreateBusinessAccounts("name");
            } else if (input.equalsIgnoreCase("exit")) {
                return;
            }
        }

    public void run() {
        String input;
        while (!(input = scanner.nextLine()).equalsIgnoreCase("exit")) {
            if (input.equalsIgnoreCase("create account")) {
                processCreateAccounts();}

            if (input.equalsIgnoreCase("show normal accounts")) {
                processShowNormalAccounts();}
            if (input.equalsIgnoreCase("show businesses accounts")) {
                processShowBusinessesAccounts();}


          //  System.out.println();
        }
    }
}
