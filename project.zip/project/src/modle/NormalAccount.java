package modle;

import java.util.ArrayList;

public class NormalAccount extends Account {

    private boolean isPublic = true;   //true:is public   false:is private
    private int allowTag = 1;  //1:everyone  2:no one  3:people you follow
    private boolean messageController = true;   // true:your follower    false:others
    private int mention = 1;  //1:everyone  2:no one  3:people you follow
    private ArrayList<String> blockedAccounts = new ArrayList<String>();

    public NormalAccount(String name, String bio, ArrayList<String> followers, ArrayList<String> following) {
        super(name, bio, followers, following);
    }
    public String getNormalAccountName() {
        return super.getName();
    }

    public void processCreateNormalAccounts(String name) {
        System.out.println("Created Normal Accounts");
    }


    public void accountPrivacy(String number) {
        if (number.equalsIgnoreCase("1")) {
           //todo
            System.out.println("account is public");

        } else if (number.equalsIgnoreCase("2")) {
            //todo
            System.out.println("account is private");
        }
    }

    public void allowTag(String number) {
        if (number.equalsIgnoreCase("1")) {
            //todo
            System.out.println("Everyone");

        } else if (number.equalsIgnoreCase("2")) {
            //todo
            System.out.println("People You Follow");
        }
        else if (number.equalsIgnoreCase("3")) {
            //todo
            System.out.println("No One");
        }
    }

    public void resharing(String number) {
        if (number.equalsIgnoreCase("1")) {
            //todo
            System.out.println("Everyone");

        } else if (number.equalsIgnoreCase("2")) {
            //todo
            System.out.println("People You Follow");
        }
        else if (number.equalsIgnoreCase("3")) {
            //todo
            System.out.println("No One");
        }
    }

    public void MessageControllers(String number) {
        if (number.equalsIgnoreCase("1")) {
            //todo
            System.out.println("Your Followers");

        } else if (number.equalsIgnoreCase("2")) {
            //todo
            System.out.println("Everyone");
        }
    }

    public void AllowMentionFrom(String number) {
        if (number.equalsIgnoreCase("1")) {
            //todo
            System.out.println("Everyone");
        }
        else if (number.equalsIgnoreCase("2")) {
            //todo
            System.out.println("No One");
        }
    }



    public void BlockedUser(String name) {
        blockedAccounts.add(String.valueOf(manager.getNormalAccountByNormalAccountName(name)));
    }

    @Override
    public String toString() {
        return "NormalAccount{" +
                "isPublic=" + isPublic +
                ", allowTag=" + allowTag +
                ", messageController=" + messageController +
                ", mention=" + mention +
                ", blockedAccounts=" + blockedAccounts +
                '}';
    }
}
