package modle;

import modle.Account;

import java.util.ArrayList;

public class BusinessAccount extends Account {
    private String email;
    private String telephonNumber;
    private String address;
    private int numberOfVisitAPost;
    public BusinessAccount(String name, String bio, ArrayList<String> followers, ArrayList<String> following) {
        super(name, bio, followers, following);
    }

    public void callWithUs(String email, String telephonNumber, String address) {
        this.email = email;
        this.telephonNumber = telephonNumber;
        this.address = address;
    }

    public void analizPosts() {
        if (super.isVisited()) {
        numberOfVisitAPost++;
        this.numberOfVisitAPost=numberOfVisitAPost;
        }
    }
    public String getBusinessAccountName() {
        return super.getName();
    }

        public void processCreateBusinessAccounts(){
            System.out.println("1");
        }

}
