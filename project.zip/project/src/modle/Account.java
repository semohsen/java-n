package modle;

import controller.Manager;

import java.util.ArrayList;

public abstract class Account {
    private String name;
    private String bio;
    // private String profilePhoto;
    private ArrayList<String> followers;
    private ArrayList<String> following;
    private boolean isVisited;
    Manager manager = new Manager();
    public Account(String name, String bio, ArrayList<String> followers, ArrayList<String> following) {
        this.name = name;
        this.bio = bio;
        this.followers = followers;
        this.following = following;
    }

    public String getName() {
        return name;
    }

    public String getBio() {
        return bio;
    }

    public ArrayList<String> getFollowers() {
        return followers;
    }

    public ArrayList<String> getFollowing() {
        return following;
    }

    public boolean isVisited() {
        return isVisited;
    }
}
